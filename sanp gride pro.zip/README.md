# SnapGrid Pro

Premium photo studio SPA for creating 4x6 printable grids.

## Features
- Matte black minimalist dashboard UI with Tailwind CSS
- File uploader with brightness and contrast sliders
- Dropdown for Indian print grids: 8, 16, 24, 32, 48 photos
- HTML5 Canvas preview of the 4x6 layout
- 300 DPI print output with zero-margin print CSS
- Placeholder remove background button

## Run locally

1. Install dependencies:
   ```bash
   npm install
   ```
2. Start the app:
   ```bash
   npm start
   ```
3. Open http://localhost:3000
