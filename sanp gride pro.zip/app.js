import { createPhotoGrid } from './photo-grid-canvas.js';

// ── Constants ─────────────────────────────────────────────────────────────────
const SHEET_W        = 6;
const SHEET_H        = 4;
const CANVAS_W       = SHEET_W * 300;
const CANVAS_H       = SHEET_H * 300;
const MAX_FILE_MB    = 15;
const FETCH_TIMEOUT  = 30_000;
const DEBOUNCE_MS    = 60;
const DEFAULT_GRID   = 48;
const LS_KEY         = 'snapgrid_settings';

// ── Settings (persisted to localStorage) ─────────────────────────────────────
const DEFAULT_SETTINGS = {
  removeBgKey:    '',
  saveKey:        true,
  bgSize:         'auto',
  bgFill:         'transparent',
  bgFillCustom:   '#1e293b',
  borderMm:       1,
  sheetBg:        '#ffffff',
  showGuides:     false,
  openrouterKey:  '',
  aiModel:        'openai/gpt-4o-mini'
};

function loadSettings() {
  try { return { ...DEFAULT_SETTINGS, ...JSON.parse(localStorage.getItem(LS_KEY) || '{}') }; }
  catch { return { ...DEFAULT_SETTINGS }; }
}

function saveSettings(s) {
  try { localStorage.setItem(LS_KEY, JSON.stringify(s)); } catch {}
}

let settings = loadSettings();


// ── Grid layouts ──────────────────────────────────────────────────────────────
const gridLayouts = {
  8:  { cols: 4, rows: 2, label: '4×2', sub: '35×45 mm', fixedCellMm: { width: 35, height: 45 } },
  16: { cols: 8, rows: 2, label: '8×2' },
  24: { cols: 6, rows: 4, label: '6×4' },
  32: { cols: 8, rows: 4, label: '8×4' },
  48: { cols: 8, rows: 6, label: '8×6' }
};

// ── DOM refs ──────────────────────────────────────────────────────────────────
const IDS = {
  fileInput:       'file-input',
  gridCardRow:     'grid-card-row',
  brightnessSlider:'brightness-slider',
  contrastSlider:  'contrast-slider',
  brightnessValue: 'brightness-value',
  contrastValue:   'contrast-value',
  removeBgButton:  'remove-bg-button',
  bgApiKey:        'bg-api-key',
  bgApiKeyToggle:  'bg-api-key-toggle',
  bgStatus:        'bg-status',
  printButton:     'print-button',
  downloadButton:  'download-button',
  canvasStatus:    'canvas-status',
  fitCoverBtn:     'fit-cover',
  fitContainBtn:   'fit-contain',
  photoCanvas:     'photo-canvas',
  photoCanvasFront:'photo-canvas-front'
};

const el = {};
let domOk = true;
for (const [key, id] of Object.entries(IDS)) {
  el[key] = document.getElementById(id);
  if (!el[key]) { console.error(`SnapGrid: #${id} not found`); domOk = false; }
}
if (!domOk) console.warn('SnapGrid: missing DOM elements — check IDs in index.html');

// ── App state ─────────────────────────────────────────────────────────────────
let activeImage      = null;
let activeBlobUrl    = null;
let lastUploadedFile = null;   // tracks last file — needed for removeBg after drag-drop
let originalImage    = null;   // stores pre-removeBg image for before/after toggle

const state = {
  gridSize:    DEFAULT_GRID,
  brightness:  1,
  contrast:    1,
  fitMode:     'cover',
  // Color grading
  exposure:    0,
  highlights:  0,
  shadows:     0,
  fade:        0,
  temperature: 0,
  tint:        0,
  saturation:  100,
  vibrance:    0,
  hue:         0,
  sharpness:   0,
  vignette:    0
};

// ── Utilities ─────────────────────────────────────────────────────────────────
function debounce(fn, ms) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

function setCanvasStatus(msg, color = '#94a3b8') {
  if (!el.canvasStatus) return;
  el.canvasStatus.textContent = msg;
  el.canvasStatus.style.color = color;
}

function setBgStatus(msg, color = '#94a3b8') {
  if (!el.bgStatus) return;
  el.bgStatus.textContent = msg;
  el.bgStatus.style.color = color;
}

function setSliderText() {
  if (el.brightnessValue) el.brightnessValue.textContent = state.brightness.toFixed(2);
  if (el.contrastValue)   el.contrastValue.textContent   = state.contrast.toFixed(2);
}

// ── Grid card builder (generates from gridLayouts data) ───────────────────────
function buildGridCards() {
  el.gridCardRow.innerHTML = '';
  for (const [sizeStr, layout] of Object.entries(gridLayouts)) {
    const size = Number(sizeStr);
    const isActive = size === state.gridSize;

    const btn = document.createElement('button');
    btn.className = 'grid-card' + (isActive ? ' active-grid' : '');
    btn.dataset.grid = size;
    btn.setAttribute('role', 'radio');
    btn.setAttribute('aria-checked', isActive ? 'true' : 'false');
    btn.setAttribute('aria-label', `${size} photos – ${layout.label}`);
    btn.title = `${size} Photos — ${layout.label}${layout.sub ? ' ' + layout.sub : ''}`;

    // CSS dot-pattern preview (no hard-coded dot divs)
    const preview = document.createElement('div');
    preview.className = 'gc-preview';
    preview.style.setProperty('--gc-cols', layout.cols);
    preview.style.setProperty('--gc-rows', layout.rows);
    preview.setAttribute('aria-hidden', 'true');

    const count = document.createElement('span');
    count.className = 'gc-count';
    count.textContent = size;

    const sub = document.createElement('span');
    sub.className = 'gc-sub';
    sub.textContent = layout.sub ?? layout.label;

    btn.append(preview, count, sub);
    el.gridCardRow.appendChild(btn);
  }
}

// ── Placeholder / canvas ──────────────────────────────────────────────────────
function drawPlaceholder() {
  el.photoCanvas.width  = CANVAS_W;
  el.photoCanvas.height = CANVAS_H;
  const ctx = el.photoCanvas.getContext('2d');
  ctx.fillStyle = '#101113';
  ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
  ctx.textAlign    = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#475569';
  ctx.font      = '42px Inter, sans-serif';
  ctx.fillText('📷  Upload a photo to begin', CANVAS_W / 2, CANVAS_H / 2 - 40);
  ctx.font      = '28px Inter, sans-serif';
  ctx.fillStyle = '#334155';
  ctx.fillText('Select a grid layout, then Download or Print', CANVAS_W / 2, CANVAS_H / 2 + 40);
}

function getLayout() {
  return gridLayouts[state.gridSize] ?? gridLayouts[DEFAULT_GRID];
}

// debouncedRender defined after renderGrid below

function renderGrid() {
  if (!activeImage) { drawPlaceholder(); return; }
  const layout = getLayout();
  // Show spinner
  const sp = document.getElementById('canvas-spinner');
  const pb = document.getElementById('render-progress');
  const bar = document.getElementById('render-bar');
  if (sp) sp.classList.add('visible');
  if (pb) { pb.classList.add('visible'); if(bar) bar.style.width='0%'; }
  setTimeout(() => { if(bar) bar.style.width='60%'; }, 50);

  requestAnimationFrame(() => {
    try {
      createPhotoGrid(el.photoCanvas, activeImage, {
        dpi:          300,
        sheetWidthIn:  SHEET_W,
        sheetHeightIn: SHEET_H,
        columns:      layout.cols,
        rows:         layout.rows,
        borderMm:     settings.borderMm,
        background:   settings.sheetBg,
        fitMode:      state.fitMode,
        brightness:   state.brightness,
        contrast:     state.contrast,
        exposure:     state.exposure,
        highlights:   state.highlights,
        shadows:      state.shadows,
        fade:         state.fade,
        temperature:  state.temperature,
        tint:         state.tint,
        saturation:   state.saturation,
        vibrance:     state.vibrance,
        hue:          state.hue,
        sharpness:    state.sharpness,
        vignette:     state.vignette,
        fixedCellMm:  layout.fixedCellMm ?? null,
        cropX:        state.cropX ?? 50,
        cropY:        state.cropY ?? 50
      });
      setCanvasStatus('');
    } catch (err) {
      console.error('renderGrid error:', err);
      setCanvasStatus(`❌ Render error: ${err.message}`, '#f87171');
    }
    // Hide spinner
    if(bar) bar.style.width='100%';
    setTimeout(() => {
      if(sp) sp.classList.remove('visible');
      if(pb) { pb.classList.remove('visible'); if(bar) bar.style.width='0%'; }
    }, 350);
    // Update count badge
    const countEl = document.getElementById('count-text');
    const badge   = document.getElementById('count-badge');
    if (countEl && badge) {
      countEl.textContent = `${state.gridSize} photos ready · ${layout.label}`;
      badge.classList.add('visible');
    }
  });
}

const debouncedRender = debounce(renderGrid, DEBOUNCE_MS);

// ── Image loading ─────────────────────────────────────────────────────────────
function loadImageElement(img) {
  activeImage = img;
  renderGrid();
}

function loadImageFile(file) {
  if (!file) { activeImage = null; drawPlaceholder(); return; }

  // File size guard
  if (file.size > MAX_FILE_MB * 1024 * 1024) {
    setCanvasStatus(`❌ File too large (max ${MAX_FILE_MB} MB).`, '#f87171');
    return;
  }
  // MIME guard
  if (!file.type.startsWith('image/')) {
    setCanvasStatus('❌ Please upload an image file (JPG, PNG, WebP).', '#f87171');
    return;
  }

  // Use createObjectURL — faster & less memory than FileReader/base64
  if (activeBlobUrl) { URL.revokeObjectURL(activeBlobUrl); activeBlobUrl = null; }
  activeBlobUrl = URL.createObjectURL(file);

  const img = new Image();
  img.onerror = () => {
    setCanvasStatus('❌ Could not decode image.', '#f87171');
    URL.revokeObjectURL(activeBlobUrl);
    activeBlobUrl = null;
  };
  img.onload = () => { loadImageElement(img); setCanvasStatus(''); };
  img.src = activeBlobUrl;
}

// ── Fit mode ──────────────────────────────────────────────────────────────────
function setFitMode(mode) {
  state.fitMode = mode;
  el.fitCoverBtn.classList.toggle('active-fit',   mode === 'cover');
  el.fitContainBtn.classList.toggle('active-fit', mode === 'contain');
  el.fitCoverBtn.setAttribute('aria-pressed',   String(mode === 'cover'));
  el.fitContainBtn.setAttribute('aria-pressed', String(mode === 'contain'));
  renderGrid();
}
el.fitCoverBtn.addEventListener('click',   () => setFitMode('cover'));
el.fitContainBtn.addEventListener('click', () => setFitMode('contain'));

// ── Grid selection ────────────────────────────────────────────────────────────
function setGridSize(size) {
  state.gridSize = size;
  el.gridCardRow.querySelectorAll('.grid-card').forEach(btn => {
    const active = Number(btn.dataset.grid) === size;
    btn.classList.toggle('active-grid', active);
    btn.setAttribute('aria-checked', String(active));
  });
  renderGrid();
}
el.gridCardRow.addEventListener('click', e => {
  const card = e.target.closest('.grid-card');
  if (card) setGridSize(Number(card.dataset.grid));
});

// ── Sliders ───────────────────────────────────────────────────────────────────
el.brightnessSlider.addEventListener('input', e => {
  state.brightness = Number(e.target.value);
  e.target.setAttribute('aria-valuenow', state.brightness);
  e.target.setAttribute('aria-valuetext', `${state.brightness.toFixed(2)}× brightness`);
  setSliderText();
  debouncedRender();
});
el.contrastSlider.addEventListener('input', e => {
  state.contrast = Number(e.target.value);
  e.target.setAttribute('aria-valuenow', state.contrast);
  e.target.setAttribute('aria-valuetext', `${state.contrast.toFixed(2)}× contrast`);
  setSliderText();
  debouncedRender();
});

// Reset buttons (optional — handled by Reset All now)
el.brightnessReset?.addEventListener('click', () => {
  state.brightness = 1;
  if (el.brightnessSlider) el.brightnessSlider.value = 1;
  setSliderText(); renderGrid();
});
el.contrastReset?.addEventListener('click', () => {
  state.contrast = 1;
  if (el.contrastSlider) el.contrastSlider.value = 1;
  setSliderText(); renderGrid();
});

// ── File input ───────────────────────────────────────────────────────────────
function handleFileSelected(file) {
  if (!file) {
    activeImage = null; lastUploadedFile = null;
    drawPlaceholder(); setActionButtons(false); updateThumbnail(null); return;
  }
  if (file.size > MAX_FILE_MB * 1024 * 1024) {
    showToast(`❌ File too large (max ${MAX_FILE_MB} MB).`, 'error'); return;
  }
  if (!file.type.startsWith('image/')) {
    showToast('❌ Please upload an image file (JPG, PNG, WebP).', 'error'); return;
  }

  setCanvasStatus(''); setBgStatus('');
  if (activeBlobUrl) { URL.revokeObjectURL(activeBlobUrl); activeBlobUrl = null; }
  activeBlobUrl = URL.createObjectURL(file);
  lastUploadedFile = file;

  const img = new Image();
  img.onerror = () => {
    showToast('❌ Could not decode image. Try a different file.', 'error');
    URL.revokeObjectURL(activeBlobUrl); activeBlobUrl = null;
    lastUploadedFile = null;
  };
  img.onload = () => {
    activeImage   = img;
    originalImage = img;       // safe — img is loaded before this runs
    renderGrid();
    updateThumbnail(file, img);
    setActionButtons(true);
    const dt = document.getElementById('drop-text');
    if (dt) dt.innerHTML = 'Photo loaded · <u>click to replace</u>';
    document.getElementById('drop-zone')?.classList.add('has-file');
  };
  img.src = activeBlobUrl;
}

el.fileInput.addEventListener('change', e => handleFileSelected(e.target.files?.[0] ?? null));
el.fileInput.addEventListener('click',  () => { el.fileInput.value = ''; });

const _dzEl = document.getElementById('drop-zone');
if (_dzEl) {
  ['dragenter','dragover'].forEach(evt => _dzEl.addEventListener(evt, e => { e.preventDefault(); _dzEl.classList.add('drag-over'); }));
  ['dragleave','dragend'].forEach(evt  => _dzEl.addEventListener(evt, () => _dzEl.classList.remove('drag-over')));
  _dzEl.addEventListener('drop', e => {
    e.preventDefault(); _dzEl.classList.remove('drag-over');
    const f = e.dataTransfer?.files?.[0];
    if (f) handleFileSelected(f);
  });
}

// ── API key show/hide ─────────────────────────────────────────────────────────
el.bgApiKeyToggle.addEventListener('click', () => {
  const isPass = el.bgApiKey.type === 'password';
  el.bgApiKey.type = isPass ? 'text' : 'password';
  el.bgApiKeyToggle.textContent = isPass ? '🙈' : '👁';
  el.bgApiKeyToggle.setAttribute('aria-label', isPass ? 'Hide API key' : 'Show API key');
});

// ── Download PNG ──────────────────────────────────────────────────────────────
el.downloadButton.addEventListener('click', async () => {
  if (!activeImage) { showToast('⚠️ Upload an image first.', 'warn'); return; }
  el.downloadButton.disabled = true;
  el.downloadButton.innerHTML = '<span>⏳</span> Preparing…';
  try {
    await new Promise(r => requestAnimationFrame(r));
    const isJpg  = exportFormat === 'jpg';
    const mime   = isJpg ? 'image/jpeg' : 'image/png';
    const ext    = isJpg ? 'jpg' : 'png';
    const link   = document.createElement('a');
    link.download = `snapgrid-${state.gridSize}up-6x4-300dpi.${ext}`;
    link.href     = el.photoCanvas.toDataURL(mime, isJpg ? 0.92 : 1);
    document.body.appendChild(link); link.click(); document.body.removeChild(link);
    showToast(`✅ Downloaded as ${ext.toUpperCase()}!`, 'success');
  } catch (err) {
    showToast(err.name === 'SecurityError' ? '❌ Canvas tainted — use a locally uploaded file.' : `❌ ${err.message}`, 'error');
  } finally {
    el.downloadButton.disabled = false;
    el.downloadButton.innerHTML = '<span aria-hidden="true">⬇</span> Download';
    setActionButtons(!!activeImage);
  }
}, true);

// ── Remove Background ──────────────────────────────────────────────────────────────────────
el.removeBgButton.addEventListener('click', async () => {
  const apiKey = el.bgApiKey.value.trim();
  if (!apiKey) { setBgStatus('⚠️ Enter your remove.bg API key first.', '#f59e0b'); return; }
  if (!lastUploadedFile) { setBgStatus('⚠️ Upload an image first.', '#f59e0b'); return; }

  setBgStatus('⏳ Removing background…');
  el.removeBgButton.disabled = true;

  const controller = new AbortController();
  const timeout    = setTimeout(() => controller.abort(), FETCH_TIMEOUT);

  try {
    const fd = new FormData();
    fd.append('image_file', lastUploadedFile);
    fd.append('size', settings?.bgSize ?? 'auto');

    const res = await fetch('https://api.remove.bg/v1.0/removebg', {
      method: 'POST', headers: { 'X-Api-Key': apiKey }, body: fd, signal: controller.signal
    });
    clearTimeout(timeout);

    if (!res.ok) {
      const j = await res.json().catch(() => ({}));
      throw new Error(j?.errors?.[0]?.title ?? `HTTP ${res.status}`);
    }

    const blob = await res.blob();
    if (activeBlobUrl) URL.revokeObjectURL(activeBlobUrl);
    activeBlobUrl = URL.createObjectURL(blob);

    const img    = new Image();
    img.onerror  = () => setBgStatus('❌ Could not decode returned image.', '#f87171');
    img.onload   = () => { loadImageElement(img); setBgStatus('✅ Background removed!', '#34d399'); };
    img.src      = activeBlobUrl;
  } catch (err) {
    clearTimeout(timeout);
    setBgStatus(
      err.name === 'AbortError' ? '❌ Timed out (30s). Try again.' : `❌ ${err.message}`,
      '#f87171'
    );
  } finally {
    el.removeBgButton.disabled = false;
  }
});

// ── Print ──────────────────────────────────────────────────────────────────────
el.printButton.addEventListener('click', () => {
  if (!activeImage) { showToast('⚠️ Upload an image before printing.', 'warn'); return; }
  const pd = document.getElementById('print-dialog');
  if (pd) { pd.showModal?.() || (pd.style.display = 'block'); }
  else {
    const front = el.photoCanvasFront;
    front.width = el.photoCanvas.width; front.height = el.photoCanvas.height;
    front.getContext('2d').drawImage(el.photoCanvas, 0, 0);
    window.print();
  }
});

// ── Cleanup on tab close ──────────────────────────────────────────────────────
window.addEventListener('beforeunload', () => {
  if (activeBlobUrl) URL.revokeObjectURL(activeBlobUrl);
});

// ── Settings panel ────────────────────────────────────────────────────────────

const settingsBtn    = document.getElementById('settings-btn');
const settingsClose  = document.getElementById('settings-close');
const settingsDrawer = document.getElementById('settings-drawer');
const settingsOverlay= document.getElementById('settings-overlay');

function openSettings() {
  settingsDrawer.hidden = false;
  requestAnimationFrame(() => {
    settingsOverlay.classList.add('open');
    settingsDrawer.classList.add('open');
  });
  settingsDrawer.setAttribute('aria-hidden', 'false');
  settingsOverlay.setAttribute('aria-hidden', 'false');
  loadSettingsIntoUI();
}

function closeSettings() {
  settingsOverlay.classList.remove('open');
  settingsDrawer.classList.remove('open');
  settingsDrawer.setAttribute('aria-hidden', 'true');
  setTimeout(() => { settingsDrawer.hidden = true; }, 300);
}

function loadSettingsIntoUI() {
  const s = settings;
  const keyEl   = document.getElementById('s-removebg-key');
  const sizeEl  = document.getElementById('s-bg-size');
  const saveEl  = document.getElementById('s-save-key-toggle');
  const sheetEl = document.getElementById('s-sheet-bg');
  const labelEl = document.getElementById('s-sheet-bg-label');
  const guidesEl= document.getElementById('s-show-guides');
  if (keyEl && s.saveKey) keyEl.value = s.removeBgKey;
  if (sizeEl)   sizeEl.value          = s.bgSize;
  if (saveEl)   saveEl.checked        = s.saveKey;
  if (sheetEl)  sheetEl.value         = s.sheetBg;
  if (labelEl)  labelEl.textContent   = s.sheetBg;
  if (guidesEl) guidesEl.checked      = s.showGuides;
  // Activate border chip
  document.querySelectorAll('#s-border-row .s-chip').forEach(c =>
    c.classList.toggle('active-chip', Number(c.dataset.border) === s.borderMm));
  // Activate fill chip
  document.querySelectorAll('#s-bg-fill-row .s-chip').forEach(c =>
    c.classList.toggle('active-chip', c.dataset.fill === s.bgFill));
  const customInput = document.getElementById('s-bg-fill-custom');
  if (customInput) { customInput.style.display = s.bgFill === 'custom' ? 'block' : 'none'; }
  // AI settings
  loadAiSettingsIntoUI();
}

if (settingsBtn)  settingsBtn.addEventListener('click', openSettings);
if (settingsClose) settingsClose.addEventListener('click', closeSettings);
if (settingsOverlay) settingsOverlay.addEventListener('click', closeSettings);
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeSettings(); });

// Save API key
const saveApiBtn = document.getElementById('s-save-api');
if (saveApiBtn) saveApiBtn.addEventListener('click', () => {
  const keyEl  = document.getElementById('s-removebg-key');
  const saveEl = document.getElementById('s-save-key-toggle');
  settings.removeBgKey = keyEl?.value.trim() ?? '';
  settings.saveKey     = saveEl?.checked ?? true;
  settings.bgSize      = document.getElementById('s-bg-size')?.value ?? 'auto';
  // Sync the sidebar API key input
  if (el.bgApiKey) el.bgApiKey.value = settings.removeBgKey;
  if (settings.saveKey) saveSettings(settings);
  else { try { localStorage.removeItem(LS_KEY); } catch {} }
  showToast('✅ API key saved!', 'success');
});

// Clear saved key
const clearApiBtn = document.getElementById('s-clear-api');
if (clearApiBtn) clearApiBtn.addEventListener('click', () => {
  settings.removeBgKey = '';
  const keyEl = document.getElementById('s-removebg-key');
  if (keyEl) keyEl.value = '';
  if (el.bgApiKey) el.bgApiKey.value = '';
  try { localStorage.removeItem(LS_KEY); } catch {}
  showToast('✅ API key cleared', 'info');
});

// API key show/hide in settings
const sKeyToggle = document.getElementById('s-removebg-key-toggle');
if (sKeyToggle) sKeyToggle.addEventListener('click', () => {
  const inp = document.getElementById('s-removebg-key');
  if (!inp) return;
  const isPass = inp.type === 'password';
  inp.type = isPass ? 'text' : 'password';
  sKeyToggle.textContent = isPass ? '🙈' : '👁';
});

// Border chip selection
const borderRow = document.getElementById('s-border-row');
if (borderRow) borderRow.addEventListener('click', e => {
  const chip = e.target.closest('.s-chip');
  if (!chip || !chip.dataset.border) return;
  settings.borderMm = Number(chip.dataset.border);
  borderRow.querySelectorAll('.s-chip').forEach(c => c.classList.toggle('active-chip', c === chip));
  saveSettings(settings); renderGrid();
});

// BG fill chip selection
const bgFillRow = document.getElementById('s-bg-fill-row');
const customColour = document.getElementById('s-bg-fill-custom');
if (bgFillRow) bgFillRow.addEventListener('click', e => {
  const chip = e.target.closest('.s-chip');
  if (!chip) return;
  settings.bgFill = chip.dataset.fill;
  bgFillRow.querySelectorAll('.s-chip').forEach(c => c.classList.toggle('active-chip', c === chip));
  if (customColour) customColour.style.display = settings.bgFill === 'custom' ? 'block' : 'none';
  saveSettings(settings); renderGrid();
});
if (customColour) customColour.addEventListener('input', e => {
  settings.bgFillCustom = e.target.value;
  saveSettings(settings); renderGrid();
});

// Sheet background colour
const sheetBgEl = document.getElementById('s-sheet-bg');
const sheetBgLabel = document.getElementById('s-sheet-bg-label');
if (sheetBgEl) sheetBgEl.addEventListener('input', e => {
  settings.sheetBg = e.target.value;
  if (sheetBgLabel) sheetBgLabel.textContent = e.target.value;
  saveSettings(settings); renderGrid();
});

// Reset all
const resetAllBtn = document.getElementById('s-reset-all');
if (resetAllBtn) resetAllBtn.addEventListener('click', () => {
  if (!confirm('Reset all settings to defaults?')) return;
  try { localStorage.removeItem(LS_KEY); } catch {}
  settings = { ...DEFAULT_SETTINGS };
  loadSettingsIntoUI();
  renderGrid();
  showToast('🔄 Settings reset', 'info');
});

// ── Auto-load saved API key into sidebar input on startup
if (el.bgApiKey && settings.saveKey && settings.removeBgKey) {
  el.bgApiKey.value = settings.removeBgKey;
}

// ── Toast system ───────────────────────────────────────────────────────────────
const toastContainer = document.getElementById('toast-container');
function showToast(msg, type = 'info', duration = 3000) {
  if (!toastContainer) return;
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.textContent = msg;
  toastContainer.appendChild(t);
  requestAnimationFrame(() => { requestAnimationFrame(() => t.classList.add('show')); });
  setTimeout(() => {
    t.classList.remove('show');
    setTimeout(() => t.remove(), 400);
  }, duration);
}

// ── Action button state management ────────────────────────────────────────────
function setActionButtons(enabled) {
  if (el.downloadButton) el.downloadButton.disabled = !enabled;
  if (el.printButton)    el.printButton.disabled    = !enabled;
  const ba = document.getElementById('ba-toggle');
  if (ba) ba.classList.toggle('visible', enabled);
  const cs = document.getElementById('crop-section');
  if (cs) cs.classList.toggle('visible', enabled);
  const cb = document.getElementById('count-badge');
  if (cb && !enabled) cb.classList.remove('visible');
  // AI Perfect Photo button
  const ae = document.getElementById('ai-enhance-btn');
  if (ae) ae.disabled = !enabled;
  const note = document.getElementById('ai-enhance-note');
  if (note) note.style.display = enabled ? 'none' : '';
}
setActionButtons(false); // disabled until image loaded

// ── Spinner & progress bar ────────────────────────────────────────────────────
const spinner  = document.getElementById('canvas-spinner');
const progWrap = document.getElementById('render-progress');
const progBar  = document.getElementById('render-bar');

function showSpinner() {
  if (spinner)  spinner.classList.add('visible');
  if (progWrap) { progWrap.classList.add('visible'); progBar.style.width = '0%'; }
  setTimeout(() => { if (progBar) progBar.style.width = '60%'; }, 50);
}
function hideSpinner() {
  if (progBar) progBar.style.width = '100%';
  setTimeout(() => {
    if (spinner)  spinner.classList.remove('visible');
    if (progWrap) { progWrap.classList.remove('visible'); progBar.style.width = '0%'; }
  }, 350);
}

// ── Thumbnail ─────────────────────────────────────────────────────────────────
const thumbWrap  = document.getElementById('thumb-wrap');
const thumbImg   = document.getElementById('thumb-img');
const thumbName  = document.getElementById('thumb-name');
const thumbSize  = document.getElementById('thumb-size');
const thumbClear = document.getElementById('thumb-clear');

function updateThumbnail(file, imgEl) {
  if (!thumbWrap) return;
  if (!file) { thumbWrap.classList.remove('visible'); const dz=document.getElementById('drop-zone'); if(dz) dz.classList.remove('has-file'); return; }
  thumbImg.src = imgEl?.src || '';
  thumbName.textContent = file.name;
  const kb = (file.size / 1024).toFixed(0);
  thumbSize.textContent = kb > 1024 ? `${(kb/1024).toFixed(1)} MB` : `${kb} KB`;
  thumbWrap.classList.add('visible');
}

function clearImage() {
  activeImage = null; lastUploadedFile = null;
  if (activeBlobUrl) { URL.revokeObjectURL(activeBlobUrl); activeBlobUrl = null; }
  if (el.fileInput) el.fileInput.value = '';
  thumbWrap?.classList.remove('visible');
  document.getElementById('drop-zone')?.classList.remove('has-file');
  const dt = document.getElementById('drop-text');
  if (dt) dt.innerHTML = 'Drop photo here or <u>click to browse</u>';
  setActionButtons(false);
  drawPlaceholder();
  undoStack = null;
  document.getElementById('undo-btn')?.classList.remove('active');
  document.getElementById('count-badge')?.classList.remove('visible');
}

if (thumbClear) thumbClear.addEventListener('click', clearImage);

// (spinner + count badge already integrated into renderGrid — no override needed)

// ── Undo stack ────────────────────────────────────────────────────────────────
let undoStack = null;
const undoBtn = document.getElementById('undo-btn');

function pushUndo() {
  undoStack = { brightness: state.brightness, contrast: state.contrast, fitMode: state.fitMode, gridSize: state.gridSize, cropX: state.cropX, cropY: state.cropY };
  undoBtn?.classList.add('active');
}

if (undoBtn) undoBtn.addEventListener('click', () => {
  if (!undoStack) return;
  const s = undoStack; undoStack = null;
  state.brightness = s.brightness; state.contrast = s.contrast;
  state.fitMode = s.fitMode; state.gridSize = s.gridSize;
  state.cropX = s.cropX ?? 50; state.cropY = s.cropY ?? 50;
  if (el.brightnessSlider) el.brightnessSlider.value = state.brightness;
  if (el.contrastSlider)   el.contrastSlider.value   = state.contrast;
  const cx = document.getElementById('crop-x-slider'); if (cx) cx.value = state.cropX;
  const cy = document.getElementById('crop-y-slider'); if (cy) cy.value = state.cropY;
  setSliderText();
  setFitMode(state.fitMode);
  setGridSize(state.gridSize);
  undoBtn.classList.remove('active');
  showToast('↩ Change undone', 'info');
});

// Push undo on slider changes
el.brightnessSlider?.addEventListener('mousedown', pushUndo);
el.contrastSlider?.addEventListener('mousedown', pushUndo);

// ── Crop position sliders ─────────────────────────────────────────────────────
state.cropX = 50; state.cropY = 50;

const cxSlider = document.getElementById('crop-x-slider');
const cySlider = document.getElementById('crop-y-slider');
const cxVal    = document.getElementById('crop-x-value');
const cyVal    = document.getElementById('crop-y-value');

if (cxSlider) cxSlider.addEventListener('input', e => {
  state.cropX = Number(e.target.value);
  if (cxVal) cxVal.textContent = `${state.cropX}%`;
  debouncedRender();
});
if (cySlider) cySlider.addEventListener('input', e => {
  state.cropY = Number(e.target.value);
  if (cyVal) cyVal.textContent = `${state.cropY}%`;
  debouncedRender();
});

// ── Zoom controls ─────────────────────────────────────────────────────────────
let zoomLevel = 1;
const zoomSteps = [0.5, 0.75, 1, 1.25, 1.5, 2];
const zoomLabel = document.getElementById('zoom-label');

function applyZoom() {
  if (el.photoCanvas) el.photoCanvas.style.transform = `scale(${zoomLevel})`;
  if (zoomLabel) zoomLabel.textContent = `${Math.round(zoomLevel * 100)}%`;
}
document.getElementById('zoom-in')?.addEventListener('click', () => {
  const i = zoomSteps.indexOf(zoomLevel); if (i < zoomSteps.length - 1) zoomLevel = zoomSteps[i + 1]; applyZoom();
});
document.getElementById('zoom-out')?.addEventListener('click', () => {
  const i = zoomSteps.indexOf(zoomLevel); if (i > 0) zoomLevel = zoomSteps[i - 1]; applyZoom();
});
document.getElementById('zoom-reset')?.addEventListener('click', () => { zoomLevel = 1; applyZoom(); });

// ── Before / After toggle ─────────────────────────────────────────────────────
let showingOriginal = false;
const baToggle = document.getElementById('ba-toggle');

if (baToggle) baToggle.addEventListener('click', () => {
  if (!originalImage || !activeImage) return;
  showingOriginal = !showingOriginal;
  baToggle.textContent = showingOriginal ? '← Back to Edited' : 'Before / After';
  baToggle.classList.toggle('active', showingOriginal);
  const tmp = activeImage;
  activeImage = showingOriginal ? originalImage : tmp;
  renderGrid();
  activeImage = tmp;
});

// ── Export format ─────────────────────────────────────────────────────────────
let exportFormat = 'png';
document.querySelectorAll('.fmt-chip[data-fmt]').forEach(btn => {
  btn.addEventListener('click', () => {
    exportFormat = btn.dataset.fmt;
    document.querySelectorAll('.fmt-chip[data-fmt]').forEach(b => b.classList.toggle('active', b === btn));
    showToast(`Export format: ${exportFormat.toUpperCase()}`, 'info', 2000);
  });
});

// ── Print pre-check dialog ────────────────────────────────────────────────────
const printDialog  = document.getElementById('print-dialog');
const printConfirm = document.getElementById('print-confirm');
const printCancel  = document.getElementById('print-cancel');
if (printConfirm) printConfirm.addEventListener('click', () => {
  printDialog?.close?.();
  const front = el.photoCanvasFront;
  if (front) {
    front.width  = el.photoCanvas.width;
    front.height = el.photoCanvas.height;
    front.getContext('2d').drawImage(el.photoCanvas, 0, 0);
  }
  window.print();
});
if (printCancel) printCancel.addEventListener('click', () => printDialog?.close?.());

// ── OpenRouter AI Settings ────────────────────────────────────────────────────
const orKeyInput    = document.getElementById('s-openrouter-key');
const orKeyToggle   = document.getElementById('s-openrouter-key-toggle');
const orModelSelect = document.getElementById('s-ai-model');
const orSaveBtn     = document.getElementById('s-save-openrouter');

function loadAiSettingsIntoUI() {
  if (orKeyInput && settings.openrouterKey) orKeyInput.value = settings.openrouterKey;
  if (orModelSelect && settings.aiModel) orModelSelect.value = settings.aiModel;
  updateAiCropHint();
}

function updateAiCropHint() {
  const hint = document.getElementById('ai-crop-hint');
  const btn  = document.getElementById('ai-crop-btn');
  if (!hint || !btn) return;
  if (settings.openrouterKey) {
    hint.style.display = 'none';
    btn.style.opacity  = '1';
    btn.style.pointerEvents = 'auto';
  } else {
    hint.style.display = '';
    btn.style.opacity  = '0.45';
    btn.style.pointerEvents = 'none';
  }
}

if (orKeyToggle) orKeyToggle.addEventListener('click', () => {
  if (!orKeyInput) return;
  const isPass = orKeyInput.type === 'password';
  orKeyInput.type = isPass ? 'text' : 'password';
  orKeyToggle.textContent = isPass ? '🙈' : '👁';
});

if (orSaveBtn) orSaveBtn.addEventListener('click', () => {
  settings.openrouterKey = orKeyInput?.value.trim() ?? '';
  settings.aiModel       = orModelSelect?.value ?? 'openai/gpt-4o-mini';
  saveSettings(settings);
  updateAiCropHint();
  showToast('✅ AI key saved!', 'success');
});

// Open settings link from sidebar hint
document.getElementById('open-ai-settings')?.addEventListener('click', e => {
  e.preventDefault(); openSettings();
});

// ── AI Smart Crop ─────────────────────────────────────────────────────────────
// Converts the current canvas to a downsized base64 JPEG for the vision API
function canvasToBase64(maxPx = 512) {
  const src = el.photoCanvas;
  const scale = Math.min(1, maxPx / Math.max(src.width, src.height));
  const tmp = document.createElement('canvas');
  tmp.width  = Math.round(src.width  * scale);
  tmp.height = Math.round(src.height * scale);
  tmp.getContext('2d').drawImage(src, 0, 0, tmp.width, tmp.height);
  return tmp.toDataURL('image/jpeg', 0.82).split(',')[1]; // base64 only
}

async function aiSmartCrop() {
  const apiKey = settings.openrouterKey;
  if (!apiKey) { showToast('⚠️ Set your OpenRouter key in Settings first.', 'warn'); return; }
  if (!activeImage) { showToast('⚠️ Upload a photo first.', 'warn'); return; }

  const btn = document.getElementById('ai-crop-btn');
  if (btn) { btn.textContent = '⏳ Analysing…'; btn.disabled = true; }

  try {
    const b64 = canvasToBase64(768);
    const model = settings.aiModel || 'openai/gpt-4o-mini';

    const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type':  'application/json',
        'HTTP-Referer':  window.location.origin,
        'X-Title':       'SnapGrid Pro'
      },
      body: JSON.stringify({
        model,
        max_tokens: 60,
        messages: [{
          role: 'user',
          content: [
            {
              type: 'text',
              text: 'This is a passport or ID photo for a photo grid. Detect the main subject (face or person). Return ONLY a valid JSON object — no markdown, no explanation — with two integer fields: cropX (0-100, horizontal focal point, 50=centre) and cropY (0-100, vertical focal point, 35=upper-third where faces usually are). Example: {"cropX":50,"cropY":32}'
            },
            {
              type: 'image_url',
              image_url: { url: `data:image/jpeg;base64,${b64}` }
            }
          ]
        }]
      })
    });

    if (!res.ok) {
      const j = await res.json().catch(() => ({}));
      throw new Error(j?.error?.message ?? `HTTP ${res.status}`);
    }

    const data = await res.json();
    const raw  = data.choices?.[0]?.message?.content ?? '';
    // Strip any markdown code fences before parsing
    const jsonStr = raw.replace(/```[\w]*\n?/g, '').trim();
    const parsed  = JSON.parse(jsonStr);

    const newX = Math.max(0, Math.min(100, Math.round(Number(parsed.cropX))));
    const newY = Math.max(0, Math.min(100, Math.round(Number(parsed.cropY))));

    if (isNaN(newX) || isNaN(newY)) throw new Error('AI returned invalid crop values.');

    // Animate sliders to the new values
    state.cropX = newX; state.cropY = newY;
    const cxS = document.getElementById('crop-x-slider');
    const cyS = document.getElementById('crop-y-slider');
    const cxV = document.getElementById('crop-x-value');
    const cyV = document.getElementById('crop-y-value');
    if (cxS) cxS.value = newX; if (cxV) cxV.textContent = `${newX}%`;
    if (cyS) cyS.value = newY; if (cyV) cyV.textContent = `${newY}%`;

    renderGrid();
    showToast(`✨ AI Crop set to X:${newX}% Y:${newY}%`, 'success');
  } catch (err) {
    showToast(`❌ AI Crop failed: ${err.message}`, 'error');
  } finally {
    if (btn) { btn.textContent = '✨ AI Crop'; btn.disabled = false; }
  }
}

document.getElementById('ai-crop-btn')?.addEventListener('click', aiSmartCrop);

// ── One-Click AI Perfect Photo ────────────────────────────────────────────────────
function setEnhanceStep(icon, main, sub) {
  const btn = document.getElementById('ai-enhance-btn');
  if (!btn) return;
  btn.innerHTML = `
    <span class="ai-enhance-icon">${icon}</span>
    <span class="ai-enhance-text">
      <strong style="color:#22d3ee">${main}</strong>
      <small style="color:#94a3b8">${sub}</small>
    </span>
    <span class="ai-enhance-badge">...</span>`;
}

function resetEnhanceBtn() {
  const btn = document.getElementById('ai-enhance-btn');
  if (!btn) return;
  btn.innerHTML = `
    <span class="ai-enhance-icon">⚡</span>
    <span class="ai-enhance-text">
      <strong>AI Perfect Photo</strong>
      <small>Remove BG · Smart Crop · Passport Grade</small>
    </span>
    <span class="ai-enhance-badge">1-CLICK</span>`;
  btn.disabled = false;
}

// Indian passport-optimised color grade preset
const PASSPORT_GRADE = {
  exposure:    0.10,
  brightness:  1.05,
  contrast:    1.08,
  highlights: -12,
  shadows:     18,
  fade:         0,
  temperature:  8,
  tint:         0,
  saturation:  92,
  vibrance:    -5,
  hue:          0,
  sharpness:   28,
  vignette:     0
};

async function oneClickAiEnhance() {
  if (!activeImage) { showToast('⚠️ Upload a photo first.', 'warn'); return; }

  const btn = document.getElementById('ai-enhance-btn');
  if (btn) btn.disabled = true;

  const removeBgKey = settings.removeBgKey || el.bgApiKey?.value?.trim() || '';
  const orKey       = settings.openrouterKey || '';
  let stepsRan = 0;

  try {
    // ── STEP 1: Remove Background ────────────────────────────────
    if (removeBgKey && lastUploadedFile) {
      setEnhanceStep('🔄', 'Removing Background…', 'Step 1 of 3 · remove.bg');
      const fd = new FormData();
      fd.append('image_file', lastUploadedFile);
      fd.append('size', settings?.bgSize ?? 'auto');
      const res = await fetch('https://api.remove.bg/v1.0/removebg', {
        method: 'POST', headers: { 'X-Api-Key': removeBgKey }, body: fd
      });
      if (res.ok) {
        const blob = await res.blob();
        if (activeBlobUrl) URL.revokeObjectURL(activeBlobUrl);
        activeBlobUrl = URL.createObjectURL(blob);
        await new Promise((resolve, reject) => {
          const img = new Image();
          img.onload = () => { activeImage = img; originalImage = img; resolve(); };
          img.onerror = reject;
          img.src = activeBlobUrl;
        });
        renderGrid();
        stepsRan++;
      } else {
        showToast('⚠️ BG removal failed — continuing…', 'warn', 2000);
      }
    } else if (!removeBgKey) {
      showToast('ℹ️ No remove.bg key — skipping BG removal', 'info', 2000);
    }

    // ── STEP 2: AI Smart Crop ─────────────────────────────────
    if (orKey && activeImage) {
      setEnhanceStep('🤖', 'AI Detecting Face…', 'Step 2 of 3 · OpenRouter Vision');
      try {
        const b64   = canvasToBase64(768);
        const model = settings.aiModel || 'openai/gpt-4o-mini';
        const res   = await fetch('https://openrouter.ai/api/v1/chat/completions', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${orKey}`, 'Content-Type': 'application/json',
            'HTTP-Referer': window.location.origin, 'X-Title': 'SnapGrid Pro' },
          body: JSON.stringify({
            model, max_tokens: 60,
            messages: [{ role: 'user', content: [
              { type: 'text', text: 'Passport photo. Detect the face/subject. Return ONLY JSON: {"cropX":50,"cropY":32} where cropX/cropY are integers 0-100 representing the focal point (50=center). For Indian passport photos, cropY should be ~30-40 so the face fills the upper portion.' },
              { type: 'image_url', image_url: { url: `data:image/jpeg;base64,${b64}` } }
            ]}]
          })
        });
        if (res.ok) {
          const data  = await res.json();
          const raw   = data.choices?.[0]?.message?.content ?? '';
          const parsed = JSON.parse(raw.replace(/```[\w]*\n?/g, '').trim());
          const newX  = Math.max(0, Math.min(100, Math.round(Number(parsed.cropX))));
          const newY  = Math.max(0, Math.min(100, Math.round(Number(parsed.cropY))));
          if (!isNaN(newX) && !isNaN(newY)) {
            state.cropX = newX; state.cropY = newY;
            const cxS = document.getElementById('crop-x-slider'); if (cxS) cxS.value = newX;
            const cyS = document.getElementById('crop-y-slider'); if (cyS) cyS.value = newY;
            const cxV = document.getElementById('crop-x-value'); if (cxV) cxV.textContent = `${newX}%`;
            const cyV = document.getElementById('crop-y-value'); if (cyV) cyV.textContent = `${newY}%`;
            stepsRan++;
          }
        }
      } catch { showToast('⚠️ AI crop failed — using center crop', 'warn', 2000); }
    } else if (!orKey) {
      showToast('ℹ️ No OpenRouter key — skipping AI crop', 'info', 2000);
    }

    // ── STEP 3: Passport Color Grade ─────────────────────────────
    setEnhanceStep('🎨', 'Applying Passport Grade…', 'Step 3 of 3 · Indian Passport Preset');
    await new Promise(r => setTimeout(r, 350));

    Object.assign(state, PASSPORT_GRADE);
    adjSliders.forEach(({ id, key, val, fmt }) => {
      const s = document.getElementById(id); if (s) s.value = state[key];
      const l = document.getElementById(val); if (l) l.textContent = fmt(state[key]);
    });
    if (el.brightnessSlider) el.brightnessSlider.value = state.brightness;
    if (el.contrastSlider)   el.contrastSlider.value   = state.contrast;
    const bv = document.getElementById('brightness-value'); if (bv) bv.textContent = state.brightness.toFixed(2);
    const cv = document.getElementById('contrast-value');   if (cv) cv.textContent = state.contrast.toFixed(2);
    stepsRan++;

    renderGrid();
    setEnhanceStep('✅', 'AI Perfect Photo Done!', `${stepsRan} enhancements applied`);
    showToast(`✨ AI Perfect Photo complete! (${stepsRan}/3 steps)`, 'success', 4000);
    setTimeout(resetEnhanceBtn, 3000);

  } catch (err) {
    showToast(`❌ Enhance failed: ${err.message}`, 'error');
    resetEnhanceBtn();
  }
}

document.getElementById('ai-enhance-btn')?.addEventListener('click', oneClickAiEnhance);

// ── Color Grading Sliders ─────────────────────────────────────────────────────
const adjSliders = [
  { id:'exposure-slider',    key:'exposure',    val:'exposure-value',    fmt: v => v.toFixed(2) },
  { id:'highlights-slider',  key:'highlights',  val:'highlights-value',  fmt: v => Math.round(v) },
  { id:'shadows-slider',     key:'shadows',     val:'shadows-value',     fmt: v => Math.round(v) },
  { id:'fade-slider',        key:'fade',        val:'fade-value',        fmt: v => Math.round(v) },
  { id:'temperature-slider', key:'temperature', val:'temperature-value', fmt: v => Math.round(v) },
  { id:'tint-slider',        key:'tint',        val:'tint-value',        fmt: v => Math.round(v) },
  { id:'saturation-slider',  key:'saturation',  val:'saturation-value',  fmt: v => Math.round(v) },
  { id:'vibrance-slider',    key:'vibrance',    val:'vibrance-value',    fmt: v => Math.round(v) },
  { id:'hue-slider',         key:'hue',         val:'hue-value',         fmt: v => `${Math.round(v)}°` },
  { id:'sharpness-slider',   key:'sharpness',   val:'sharpness-value',   fmt: v => Math.round(v) },
  { id:'vignette-slider',    key:'vignette',    val:'vignette-value',    fmt: v => Math.round(v) },
];

adjSliders.forEach(({ id, key, val, fmt }) => {
  const slider = document.getElementById(id);
  const label  = document.getElementById(val);
  if (!slider) return;
  slider.addEventListener('input', e => {
    state[key] = Number(e.target.value);
    if (label) label.textContent = fmt(state[key]);
    debouncedRender();
  });
});

// Reset All Adjustments
document.getElementById('adj-reset-all')?.addEventListener('click', () => {
  const defaults = { brightness:1, contrast:1, exposure:0, highlights:0, shadows:0,
    fade:0, temperature:0, tint:0, saturation:100, vibrance:0, hue:0, sharpness:0, vignette:0 };
  Object.assign(state, defaults);
  // Reset slider positions + labels
  adjSliders.forEach(({ id, key, val, fmt }) => {
    const s = document.getElementById(id); if (s) s.value = state[key];
    const l = document.getElementById(val); if (l) l.textContent = fmt(state[key]);
  });
  // Reset brightness/contrast too
  if (el.brightnessSlider) el.brightnessSlider.value = 1;
  if (el.contrastSlider)   el.contrastSlider.value   = 1;
  const bv = document.getElementById('brightness-value'); if (bv) bv.textContent = '1.00';
  const cv = document.getElementById('contrast-value');   if (cv) cv.textContent = '1.00';
  setSliderText();
  renderGrid();
  showToast('↺ All adjustments reset', 'info');
});

// ── Init ──────────────────────────────────────────────────────────────────────
buildGridCards();
setFitMode('cover');
setSliderText();
setGridSize(DEFAULT_GRID);
drawPlaceholder();
updateAiCropHint();
showToast('👋 Welcome! Drop a photo or click Upload to start.', 'info', 4000);
