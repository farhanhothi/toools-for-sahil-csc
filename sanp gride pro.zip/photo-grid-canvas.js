/** SnapGrid Pro – photo-grid-canvas.js
 *  Full color-grading pipeline (cross-browser, single pixel pass).
 */

// ── Helpers ───────────────────────────────────────────────────────────────────
function clamp(v) { return v < 0 ? 0 : v > 255 ? 255 : v | 0; }

function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  const l = (max + min) / 2;
  if (max === min) return [0, 0, l];
  const d = max - min;
  const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
  let h;
  switch (max) {
    case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
    case g: h = ((b - r) / d + 2) / 6; break;
    default: h = ((r - g) / d + 4) / 6;
  }
  return [h, s, l];
}

function hue2rgb(p, q, t) {
  if (t < 0) t += 1; if (t > 1) t -= 1;
  if (t < 1 / 6) return p + (q - p) * 6 * t;
  if (t < 1 / 2) return q;
  if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
  return p;
}

function hslToRgb(h, s, l) {
  if (s === 0) { const v = Math.round(l * 255); return [v, v, v]; }
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p = 2 * l - q;
  return [
    Math.round(hue2rgb(p, q, h + 1 / 3) * 255),
    Math.round(hue2rgb(p, q, h) * 255),
    Math.round(hue2rgb(p, q, h - 1 / 3) * 255)
  ];
}

// ── Main pixel processing (single pass) ───────────────────────────────────────
function processPixels(imageData, o) {
  const expMult  = Math.pow(2, o.exposure  || 0);
  const bri      = o.brightness  ?? 1;
  const con      = o.contrast    ?? 1;
  const hl       = (o.highlights || 0) * 0.8;
  const sh       = (o.shadows    || 0) * 0.8;
  const fadeFrac = (o.fade       || 0) / 100;
  const tempAdj  = (o.temperature || 0) * 0.5;
  const tintAdj  = (o.tint       || 0) * 0.25;
  const sat      = (o.saturation  ?? 100) / 100;
  const vib      = (o.vibrance   || 0) / 100;
  const hueShift = (o.hue        || 0) / 360;
  const needsHsl = sat !== 1 || vib !== 0 || hueShift !== 0;

  const d = imageData.data;
  for (let i = 0; i < d.length; i += 4) {
    let r = d[i], g = d[i + 1], b = d[i + 2];

    // Exposure
    r *= expMult; g *= expMult; b *= expMult;

    // Highlights / Shadows (luminance-weighted)
    const luma   = 0.299 * r + 0.587 * g + 0.114 * b;
    const hlFact = (luma / 255) ** 2;
    const shFact = (1 - luma / 255) ** 2;
    const adj    = hl * hlFact + sh * shFact;
    r += adj; g += adj; b += adj;

    // Fade (lift blacks)
    r = r * (1 - fadeFrac) + fadeFrac * 30;
    g = g * (1 - fadeFrac) + fadeFrac * 30;
    b = b * (1 - fadeFrac) + fadeFrac * 30;

    // Brightness & Contrast
    r *= bri; g *= bri; b *= bri;
    r = (r - 127.5) * con + 127.5;
    g = (g - 127.5) * con + 127.5;
    b = (b - 127.5) * con + 127.5;

    // Temperature (R↑B↓ = warm, R↓B↑ = cool)
    r += tempAdj; b -= tempAdj;
    // Tint (G↑ = green, G↓ = magenta)
    g += tintAdj;

    // Clamp before HSL
    r = clamp(r); g = clamp(g); b = clamp(b);

    // Saturation / Vibrance / Hue
    if (needsHsl) {
      let [h, s, l] = rgbToHsl(r, g, b);
      // Hue rotation
      h = ((h + hueShift) % 1 + 1) % 1;
      // Vibrance (selective — more effect on less-saturated pixels)
      if (vib > 0) s = s + vib * (1 - s);
      else         s = Math.max(0, s + vib * s);
      // Saturation (global)
      s = Math.max(0, Math.min(1, s * sat));
      [r, g, b] = hslToRgb(h, s, l);
    }

    d[i] = clamp(r); d[i + 1] = clamp(g); d[i + 2] = clamp(b);
  }
}

// ── Sharpness (unsharp mask, second pass) ─────────────────────────────────────
function applySharpness(imageData, amount) {
  if (!amount) return;
  const { width: w, height: h, data: d } = imageData;
  const src = new Uint8ClampedArray(d);
  const str = amount / 100;
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = (y * w + x) * 4;
      for (let c = 0; c < 3; c++) {
        const center = src[i + c];
        const nbrs   = src[((y-1)*w+x)*4+c] + src[((y+1)*w+x)*4+c]
                     + src[(y*w+x-1)*4+c]   + src[(y*w+x+1)*4+c];
        d[i + c] = Math.min(255, Math.max(0, center + str * (4 * center - nbrs)));
      }
    }
  }
}

// ── Main export ───────────────────────────────────────────────────────────────
export function createPhotoGrid(canvas, image, options = {}) {
  const {
    dpi = 300, sheetWidthIn = 6, sheetHeightIn = 4,
    columns = 8, rows = 6, borderMm = 1,
    background = '#ffffff', fitMode = 'cover',
    brightness = 1, contrast = 1, exposure = 0,
    highlights = 0, shadows = 0, fade = 0,
    temperature = 0, tint = 0, saturation = 100,
    vibrance = 0, hue = 0, sharpness = 0, vignette = 0,
    fixedCellMm = null, cropX = 50, cropY = 50
  } = options;

  if (!canvas || !image) throw new Error('canvas and image are required');

  const mmPerIn  = 25.4;
  const borderPx = (borderMm / mmPerIn) * dpi;
  const widthPx  = Math.round(sheetWidthIn  * dpi);
  const heightPx = Math.round(sheetHeightIn * dpi);

  canvas.width  = widthPx;
  canvas.height = heightPx;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D context unavailable');

  // Cell geometry
  let cellW = 0, cellH = 0, offsetX = borderPx, offsetY = borderPx;
  if (fixedCellMm?.width && fixedCellMm?.height) {
    cellW = Math.round((fixedCellMm.width  / mmPerIn) * dpi);
    cellH = Math.round((fixedCellMm.height / mmPerIn) * dpi);
    const totalW = columns * cellW + (columns + 1) * borderPx;
    const totalH = rows    * cellH + (rows    + 1) * borderPx;
    offsetX = Math.max(borderPx, Math.round((widthPx  - totalW) / 2) + borderPx);
    offsetY = Math.max(borderPx, Math.round((heightPx - totalH) / 2) + borderPx);
  } else {
    cellW = Math.round((widthPx  - (columns + 1) * borderPx) / columns);
    cellH = Math.round((heightPx - (rows    + 1) * borderPx) / rows);
  }

  ctx.fillStyle = background;
  ctx.fillRect(0, 0, widthPx, heightPx);

  const imgW = image.naturalWidth  || image.width  || 1;
  const imgH = image.naturalHeight || image.height || 1;

  // Focal point (0–1)
  const cx = Math.max(0, Math.min(1, cropX / 100));
  const cy = Math.max(0, Math.min(1, cropY / 100));

  // ── Build adjusted source image (once) ──────────────────────────────────
  const defaults = { brightness:1, contrast:1, exposure:0, highlights:0,
    shadows:0, fade:0, temperature:0, tint:0, saturation:100, vibrance:0, hue:0, sharpness:0 };
  const needsPixel = Object.keys(defaults).some(k => options[k] !== undefined && options[k] !== defaults[k]);

  let drawSrc = image;
  if (needsPixel) {
    const maxDim = 2400;
    const scale  = Math.min(1, maxDim / Math.max(imgW, imgH));
    const sw = Math.round(imgW * scale), sh = Math.round(imgH * scale);
    const off  = document.createElement('canvas');
    off.width  = sw; off.height = sh;
    const octx = off.getContext('2d');
    octx.drawImage(image, 0, 0, sw, sh);
    const pxData = octx.getImageData(0, 0, sw, sh);
    processPixels(pxData, { brightness, contrast, exposure, highlights, shadows,
      fade, temperature, tint, saturation, vibrance, hue });
    if (sharpness) applySharpness(pxData, sharpness);
    octx.putImageData(pxData, 0, 0);
    drawSrc = off;
  }

  const srcW = drawSrc.naturalWidth  || drawSrc.width  || imgW;
  const srcH = drawSrc.naturalHeight || drawSrc.height || imgH;
  const srcRatio = srcW / srcH;

  // ── Draw cell ─────────────────────────────────────────────────────────────
  const drawCell = (x, y, w, h) => {
    const cellRatio = w / h;
    let dw, dh, px, py;
    if (fitMode === 'cover') {
      if (srcRatio > cellRatio) { dw = h * srcRatio; dh = h; px = x - (dw - w) * cx; py = y; }
      else                      { dw = w; dh = w / srcRatio; px = x; py = y - (dh - h) * cy; }
    } else {
      if (srcRatio > cellRatio) { dw = w; dh = w / srcRatio; px = x; py = y + (h - dh) / 2; }
      else                      { dh = h; dw = h * srcRatio; px = x + (w - dw) / 2; py = y; }
    }
    ctx.save();
    ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
    ctx.drawImage(drawSrc, px, py, dw, dh);
    ctx.restore();
  };

  for (let r = 0; r < rows; r++)
    for (let c = 0; c < columns; c++)
      drawCell(offsetX + c * (cellW + borderPx), offsetY + r * (cellH + borderPx), cellW, cellH);

  // ── Vignette overlay ──────────────────────────────────────────────────────
  if (vignette > 0) {
    const str  = vignette / 100;
    const grad = ctx.createRadialGradient(
      widthPx / 2, heightPx / 2, Math.min(widthPx, heightPx) * 0.28,
      widthPx / 2, heightPx / 2, Math.max(widthPx, heightPx) * 0.78
    );
    grad.addColorStop(0, 'rgba(0,0,0,0)');
    grad.addColorStop(1, `rgba(0,0,0,${(str * 0.88).toFixed(3)})`);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, widthPx, heightPx);
  }

  return canvas;
}
