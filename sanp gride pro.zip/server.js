import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();

app.use(express.static(__dirname));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/api/remove-background', (req, res) => {
  res.status(501).json({
    message: 'Background removal is a placeholder endpoint. Implement a real service to enable this feature.'
  });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`SnapGrid Pro server running at http://localhost:${port}`);
});
