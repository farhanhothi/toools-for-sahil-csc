import { createPhotoGrid } from './photo-grid-canvas.js';

const fileInput = document.getElementById('file-input');
const gridSelect = document.getElementById('grid-select');
const brightnessSlider = document.getElementById('brightness-slider');
const contrastSlider = document.getElementById('contrast-slider');
const brightnessValue = document.getElementById('brightness-value');
const contrastValue = document.getElementById('contrast-value');
const removeBgButton = document.getElementById('remove-bg-button');
const printButton = document.getElementById('print-button');
const photoCanvas = document.getElementById('photo-canvas');

let activeImage = null;
let state = {
  gridSize: 48,
  brightness: 1,
  contrast: 1,
  fitMode: 'cover'
};

const gridLayouts = {
  8: { cols: 2, rows: 4, fixedCellMm: { width: 35, height: 45 } },
  16: { cols: 4, rows: 4 },
  24: { cols: 4, rows: 6 },
  32: { cols: 4, rows: 8 },
  48: { cols: 6, rows: 8 }
};

function setStatusText() {
  brightnessValue.textContent = state.brightness.toFixed(2);
  contrastValue.textContent = state.contrast.toFixed(2);
}

function loadImageFile(file) {
  if (!file) {
    activeImage = null;
    drawPlaceholder();
    return;
  }

  const reader = new FileReader();
  reader.onload = () => {
    const image = new Image();
    image.onload = () => {
      activeImage = image;
      renderGrid();
    };
    image.src = reader.result;
  };
  reader.readAsDataURL(file);
}

function drawPlaceholder() {
  const ctx = photoCanvas.getContext('2d');
  ctx.save();
  ctx.fillStyle = '#101113';
  ctx.fillRect(0, 0, photoCanvas.width, photoCanvas.height);
  ctx.fillStyle = '#64748b';
  ctx.font = '26px Inter, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('Upload an image to preview your 4x6 grid.', photoCanvas.width / 2, photoCanvas.height / 2 - 20);
  ctx.font = '20px Inter, sans-serif';
  ctx.fillText('Select a grid layout and hit Print Now.', photoCanvas.width / 2, photoCanvas.height / 2 + 24);
  ctx.restore();
}

function getLayoutOptions() {
  return gridLayouts[state.gridSize] ?? gridLayouts[48];
}

function renderGrid() {
  if (!activeImage) {
    drawPlaceholder();
    return;
  }

  const layout = getLayoutOptions();
  const options = {
    dpi: 300,
    sheetWidthIn: 4,
    sheetHeightIn: 6,
    columns: layout.cols,
    rows: layout.rows,
    borderMm: 1,
    background: '#ffffff',
    fitMode: state.fitMode,
    brightness: state.brightness,
    contrast: state.contrast,
    fixedCellMm: layout.fixedCellMm
  };

  createPhotoGrid(photoCanvas, activeImage, options);
}

fileInput.addEventListener('change', (event) => {
  loadImageFile(event.target.files?.[0]);
});

gridSelect.addEventListener('change', (event) => {
  state.gridSize = Number(event.target.value);
  renderGrid();
});

brightnessSlider.addEventListener('input', (event) => {
  state.brightness = Number(event.target.value);
  setStatusText();
  renderGrid();
});

contrastSlider.addEventListener('input', (event) => {
  state.contrast = Number(event.target.value);
  setStatusText();
  renderGrid();
});

removeBgButton.addEventListener('click', () => {
  alert('Remove Background is a placeholder feature in this demo.');
});

printButton.addEventListener('click', () => {
  const frontCanvas = document.getElementById('photo-canvas-front');
  const backCanvas = document.getElementById('photo-canvas-back');
  const ctxFront = frontCanvas.getContext('2d');
  const ctxBack = backCanvas.getContext('2d');

  // Copy the main canvas to front and back
  ctxFront.drawImage(photoCanvas, 0, 0);
  ctxBack.drawImage(photoCanvas, 0, 0); // Same for back, or modify if needed

  window.print();
});

setStatusText();
drawPlaceholder();
