/**
 * Create a photo grid on a 4x6 inch sheet at 300 DPI using HTML5 Canvas.
 *
 * @param {HTMLCanvasElement} canvas - The target canvas element.
 * @param {HTMLImageElement|HTMLCanvasElement} image - The uploaded image source.
 * @param {object} [options] - Optional settings.
 * @param {number} [options.dpi=300] - Output DPI.
 * @param {number} [options.sheetWidthIn=4] - Sheet width in inches.
 * @param {number} [options.sheetHeightIn=6] - Sheet height in inches.
 * @param {number} [options.columns=6] - Number of columns.
 * @param {number} [options.rows=8] - Number of rows.
 * @param {number} [options.borderMm=1] - Cutting border thickness in millimeters.
 * @param {string} [options.background='#ffffff'] - Background color for borders.
 * @param {'contain'|'cover'} [options.fitMode='contain'] - Image scaling mode.
 * @param {number} [options.brightness=1] - Brightness multiplier.
 * @param {number} [options.contrast=1] - Contrast multiplier.
 * @param {object} [options.fixedCellMm] - Fixed cell size for special layouts.
 * @param {number} [options.fixedCellMm.width] - Cell width in mm.
 * @param {number} [options.fixedCellMm.height] - Cell height in mm.
 *
 * @returns {HTMLCanvasElement} The canvas element with the generated grid.
 */
export function createPhotoGrid(canvas, image, options = {}) {
  const {
    dpi = 300,
    sheetWidthIn = 4,
    sheetHeightIn = 6,
    columns = 6,
    rows = 8,
    borderMm = 1,
    background = '#ffffff',
    fitMode = 'contain',
    brightness = 1,
    contrast = 1,
    fixedCellMm = null
  } = options;

  const mmToIn = 1 / 25.4;
  const borderPx = borderMm * mmToIn * dpi;
  const widthPx = Math.round(sheetWidthIn * dpi);
  const heightPx = Math.round(sheetHeightIn * dpi);

  let cellWidth = 0;
  let cellHeight = 0;
  let offsetX = borderPx;
  let offsetY = borderPx;

  if (fixedCellMm && fixedCellMm.width && fixedCellMm.height) {
    cellWidth = Math.round(fixedCellMm.width * mmToIn * dpi);
    cellHeight = Math.round(fixedCellMm.height * mmToIn * dpi);
    const totalWidth = columns * cellWidth + (columns + 1) * borderPx;
    const totalHeight = rows * cellHeight + (rows + 1) * borderPx;
    offsetX = Math.round((widthPx - totalWidth) / 2 + borderPx);
    offsetY = Math.round((heightPx - totalHeight) / 2 + borderPx);
  } else {
    cellWidth = (widthPx - (columns + 1) * borderPx) / columns;
    cellHeight = (heightPx - (rows + 1) * borderPx) / rows;
  }

  canvas.width = widthPx;
  canvas.height = heightPx;

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Canvas 2D context not available.');
  }

  ctx.clearRect(0, 0, widthPx, heightPx);
  ctx.fillStyle = background;
  ctx.fillRect(0, 0, widthPx, heightPx);

  const imageWidth = image.naturalWidth || image.width;
  const imageHeight = image.naturalHeight || image.height;
  const imageRatio = imageWidth / imageHeight || 1;

  const drawImageInCell = (cellX, cellY, width, height) => {
    const cellRatio = width / height;
    let drawWidth = width;
    let drawHeight = height;
    let posX = cellX;
    let posY = cellY;

    if (fitMode === 'cover') {
      if (imageRatio > cellRatio) {
        drawWidth = height * imageRatio;
        drawHeight = height;
        posX = cellX - (drawWidth - width) / 2;
      } else {
        drawWidth = width;
        drawHeight = width / imageRatio;
        posY = cellY - (drawHeight - height) / 2;
      }
    } else {
      if (imageRatio > cellRatio) {
        drawWidth = width;
        drawHeight = width / imageRatio;
        posY = cellY + (height - drawHeight) / 2;
      } else {
        drawHeight = height;
        drawWidth = height * imageRatio;
        posX = cellX + (width - drawWidth) / 2;
      }
    }

    ctx.drawImage(image, posX, posY, drawWidth, drawHeight);
  };

  const originalFilter = ctx.filter;
  ctx.filter = `brightness(${brightness}) contrast(${contrast})`;

  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < columns; col++) {
      const x = offsetX + col * (cellWidth + borderPx);
      const y = offsetY + row * (cellHeight + borderPx);
      drawImageInCell(x, y, cellWidth, cellHeight);
    }
  }

  ctx.filter = originalFilter;
  return canvas;
}

